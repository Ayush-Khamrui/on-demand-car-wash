package com.carwash.order.models;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.mongodb.core.mapping.Field;

@Document
public class Order {
	@Id
	private String orderId;
	@Field
	private String orderDate;
	@Field
	private String location;
	@Field
	private User user;
	@Field
	private Washer washer;
	
	
	public Order(String orderId, String orderDate, String location, User user, Washer washer) {
		super();
		this.orderId = orderId;
		this.orderDate = orderDate;
		this.location = location;
		this.user = user;
		this.washer = washer;
	}
	
	public String getOrderId() {
		return orderId;
	}
	public void setOrderId(String orderId) {
		this.orderId = orderId;
	}
	public String getOrderDate() {
		return orderDate;
	}
	public void setOrderDate(String orderDate) {
		this.orderDate = orderDate;
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	public User getUser() {
		return user;
	}
	public void setUser(User user) {
		this.user = user;
	}
	public Washer getWasher() {
		return washer;
	}
	public void setWasher(Washer washer) {
		this.washer = washer;
	}
	
	
	
}
