package com.carwash.order.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

import com.carwash.order.models.Order;
import com.carwash.order.services.OrderService;

public class OrderController {
	@Autowired
	private OrderService service;
	
	@GetMapping("/getall")
	public List<Order> getOrder(){
		return service.getOrder();
	}
	
	@PostMapping("/register")
	public ResponseEntity<String> insertOrder(@RequestBody Order order) {
		System.out.println("Order generated");
		service.addOrder(order);
		return new ResponseEntity<String>("Success", HttpStatus.OK);
	}
	
	@DeleteMapping("/deleteorder/{orderId}")
	public ResponseEntity<String> deleteOrderById(@PathVariable("orderId")String orderId){
		service.deleteOrder(orderId);
		return new ResponseEntity<String>("Delete-successfully",HttpStatus.OK);
	}
}
